//  KeyboardViewController.swift
//  keyboard
//
//  Created by MacBook Pro on 29/12/2023.
//

import UIKit

class KeyboardViewController: UIInputViewController {
    
    @IBOutlet var nextKeyboardButton: UIButton!
    var isUppercase = false
    var stackView: UIStackView!
    
    override func updateViewConstraints() {
        super.updateViewConstraints()
        // Add custom view sizing constraints here
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Create the main stack view
        stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
        stackView.spacing = 5  // Adjust the spacing between rows
        
        // Define the rows of characters
        let rows = Constants.letterKeys
        
        // Add buttons to the stack view
        for rowCharacters in rows {
            let rowStackView = UIStackView()
            rowStackView.axis = .horizontal
            rowStackView.alignment = .fill
            rowStackView.distribution = .fillEqually
            
            for character in rowCharacters {
                let button = UIButton(type: .system)
                button.setTitle(character, for: .normal)
                button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
                button.setTitleColor(.darkText, for: .normal)
                button.backgroundColor = Constants.keyNormalColour
                button.layer.cornerRadius = 8
                button.layer.borderWidth = 0.5
                button.layer.borderColor = UIColor(white: 0.8, alpha: 1.0).cgColor
                
                // Handle special cases
                switch character {
                case "🌐": // Globe Icon for Switching Keyboards
                    button.addTarget(self, action: #selector(switchKeyboard(_:)), for: .touchUpInside)
                case "space":
                    button.addTarget(self, action: #selector(spacePressed(_:)), for: .touchUpInside)
                case "↩": // Return Key
                    button.addTarget(self, action: #selector(returnPressed(_:)), for: .touchUpInside)
                case "⬆️": // Uppercase Key
                    button.addTarget(self, action: #selector(toggleUppercase(_:)), for: .touchUpInside)
                case "123": // Numerical Key
                    button.addTarget(self, action: #selector(toggleNumerical(_:)), for: .touchUpInside)
                case "ABC": // Numerical Key
                    button.addTarget(self, action: #selector(toggleAlphabetics(_:)), for: .touchUpInside)
                default:
                    button.addTarget(self, action: #selector(buttonPressed(_:)), for: .touchUpInside)
                }
                
                rowStackView.addArrangedSubview(button)
            }
            
            stackView.addArrangedSubview(rowStackView)
        }
        
        // Add the stack view to the main view
        view.addSubview(stackView)
        
        // Set up Autolayout constraints for the stack view
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        stackView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        stackView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
    }
    
    @objc func switchKeyboard(_ sender: UIButton) {
        advanceToNextInputMode()
    }
    
    @objc func spacePressed(_ sender: UIButton) {
        if isUppercase {
            toggleUppercase(sender)
        }
        textDocumentProxy.insertText(" ")
    }
    
    @objc func returnPressed(_ sender: UIButton) {
        textDocumentProxy.insertText("\n")
    }
    
    @objc func toggleUppercase(_ sender: UIButton) {
        isUppercase.toggle()
        
        for case let rowStack as UIStackView in stackView.arrangedSubviews {
            for case let button as UIButton in rowStack.arrangedSubviews {
                if let title = button.title(for: .normal), Constants.letterKeys.contains(where: { $0.contains(title.lowercased()) }) {
                    let newTitle = isUppercase ? title.uppercased() : title.lowercased()
                    button.setTitle(newTitle, for: .normal)
                }
            }
        }
    }
    
    @objc func toggleNumerical(_ sender: UIButton) {
        updateKeyboardLayout(with: Constants.numberKeys)
    }
    @objc func toggleAlphabetics(_ sender: UIButton) {
        updateKeyboardLayout(with: Constants.letterKeys)
    }
    
    // Add a helper function to update the keyboard layout
    func updateKeyboardLayout(with keys: [[String]]) {
        // Clear existing arranged subviews
        stackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        
        // Add buttons to the stack view
        for rowCharacters in keys {
            let rowStackView = UIStackView()
            rowStackView.axis = .horizontal
            rowStackView.alignment = .fill
            rowStackView.distribution = .fillEqually
            
            for character in rowCharacters {
                let button = UIButton(type: .system)
                button.setTitle(character, for: .normal)
                button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
                button.setTitleColor(.darkText, for: .normal)
                button.backgroundColor = Constants.keyNormalColour
                button.layer.cornerRadius = 8
                button.layer.borderWidth = 0.5
                button.layer.borderColor = UIColor(white: 0.8, alpha: 1.0).cgColor
                
                // Handle special cases
                switch character {
                case "🌐": // Globe Icon for Switching Keyboards
                    button.addTarget(self, action: #selector(switchKeyboard(_:)), for: .touchUpInside)
                case "space":
                    button.addTarget(self, action: #selector(spacePressed(_:)), for: .touchUpInside)
                case "↩": // Return Key
                    button.addTarget(self, action: #selector(returnPressed(_:)), for: .touchUpInside)
                case "⬆️": // Uppercase Key
                    button.addTarget(self, action: #selector(toggleUppercase(_:)), for: .touchUpInside)
                case "123": // Numerical Key
                    button.addTarget(self, action: #selector(togglenumerical(_:)), for: .touchUpInside)
                case "ABC": // Alphabetic Key
                    button.addTarget(self, action: #selector(toggleAlphabetic(_:)), for: .touchUpInside)
                case "#+=": // Alphabetic Key
                    button.addTarget(self, action: #selector(togglesymbols(_:)), for: .touchUpInside)
                default:
                    button.addTarget(self, action: #selector(buttonPressed(_:)), for: .touchUpInside)
                }
                
                rowStackView.addArrangedSubview(button)
            }
            
            stackView.addArrangedSubview(rowStackView)
        }
    }
    
    @objc func toggleAlphabetic(_ sender: UIButton) {
        updateKeyboardLayout(with: Constants.letterKeys)
    }
    @objc func togglenumerical(_ sender: UIButton) {
        updateKeyboardLayout(with: Constants.numberKeys)
    }
    @objc func togglesymbols(_ sender: UIButton) {
        updateKeyboardLayout(with: Constants.symbolKeys)
    }
    
    @objc func buttonPressed(_ sender: UIButton) {
        if let title = sender.title(for: .normal) {
            switch title {
            case "⌫":
                textDocumentProxy.deleteBackward()
            case "Switch 🌐", "123", "⬆️": // Ignore these buttons for text input
                break
            case "Next Line ↩︎":
                textDocumentProxy.insertText("\n")
            default:
                if isUppercase {
                    toggleUppercase(sender)
                }
                textDocumentProxy.insertText(title)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated
    }
}

